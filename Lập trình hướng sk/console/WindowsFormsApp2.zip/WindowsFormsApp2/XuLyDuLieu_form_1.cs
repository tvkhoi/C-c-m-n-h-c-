﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp2
{
    internal interface XuLyDuLieu_form_1
    {
        void xulydulieu(string mabn,string dichvu,string ngay, string thang, string nam);
        string layMa();
        
    }
}
